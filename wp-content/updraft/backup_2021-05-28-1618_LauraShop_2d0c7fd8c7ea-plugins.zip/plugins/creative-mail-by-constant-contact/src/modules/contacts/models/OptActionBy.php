<?php


namespace CreativeMail\Modules\Contacts\Models;


class OptActionBy
{
    const Visitor = 1;
    const Owner = 2;
}