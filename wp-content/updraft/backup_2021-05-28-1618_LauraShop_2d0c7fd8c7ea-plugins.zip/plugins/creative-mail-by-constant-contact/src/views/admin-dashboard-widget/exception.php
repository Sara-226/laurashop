<div style="display: flex;">
    <section style="flex: 1;">
        <p style="margin-top: 0;"><?= __( 'Well... this is embarrassing!', 'ce4wp' ); ?></p>
        <p><?= __( 'Creative Mail ran into an error.', 'ce4wp' ); ?></p>
        <p><?= __( 'Please try again at a later time.', 'ce4wp') ?></p>
    </section>
    <img
        src="<?= CE4WP_PLUGIN_URL . 'assets/images/admin-dashboard-widget/creative-mail.png'; ?>"
        style="margin-top: -11px; margin-right: -12px; height: 10em;"
    />
</div>
